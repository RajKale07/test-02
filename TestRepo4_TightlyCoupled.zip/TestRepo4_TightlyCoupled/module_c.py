def func_c():
    print("Function C")
