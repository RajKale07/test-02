from module_c import func_c

def func_b():
    print("Function B")
    func_c()
